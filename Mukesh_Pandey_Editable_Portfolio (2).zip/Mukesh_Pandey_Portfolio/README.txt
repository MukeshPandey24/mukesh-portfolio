MUKESH PANDEY — EDITABLE PORTFOLIO WEBSITE

FILES
- assets/mukesh-pandey.jpg: your uploaded profile photo used on the homepage.
- index.html: responsive personal portfolio (HTML/CSS/JS; no build tools).
- projects/retail_sales_practice_dataset.csv: generated practice dataset for the first case study.

PREVIEW
1. Extract the ZIP.
2. Double-click index.html to open it in a browser.

EDIT
1. Open index.html in Notepad or Visual Studio Code.
2. Search for the wording you want to change and edit it.
3. Save, then refresh the browser.
4. Keep the projects folder beside index.html so the CSV download link works.

CONTACT
Email: mkr88539@gmail.com
LinkedIn: https://www.linkedin.com/in/mukesh-pandey-0085781b8

IMPORTANT
- Retail Sales Performance Analysis uses synthetic practice data, not real company/client data.
- Customer Segmentation and Power BI Dashboard are marked planned, not completed.
- Verify exact MBA programme title, dates, job title and employment dates before publishing.
- Only list tools and skills you can confidently explain in an interview.

PUBLISH ONLINE WITH GITHUB PAGES
1. Sign in to GitHub and create a public repository named mukesh-portfolio.
2. Upload index.html and the projects folder to the repository root.
3. Open Settings > Pages.
4. Choose Deploy from a branch, select main and /(root), then Save.
5. Once published, copy the public URL and add it to your Internshala Portfolio / Work Samples section.

Keep a backup copy of this ZIP before editing.
